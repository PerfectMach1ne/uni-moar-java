package CwiczeniaLab2.TwoOne;

public class TwoOne {
    public static void main(String[] args) {
        for (int i = 1; i < 13; i++) System.out.print(i + " ");
    }
}
