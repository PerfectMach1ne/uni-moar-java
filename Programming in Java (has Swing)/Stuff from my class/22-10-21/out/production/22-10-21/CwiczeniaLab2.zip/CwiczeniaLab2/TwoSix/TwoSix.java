package CwiczeniaLab2.TwoSix;

public class TwoSix {
    public static void main(String[] args) {
        System.out.println("Obwod kola o promieniu 7.5 = " + 2*Math.PI*7.5);
        System.out.println("Pole powierzchni kola o promieniu 7.5 = " + Math.PI*Math.pow(7.5,2));
    }
}
